import java.util.*;

public class ACT_3_ARRAYS {
	public static void main(String[] args) {
		Scanner sab = new Scanner(System.in);
		
		int NumSub, average, sumsco=0;
		int scores[] = new int[10];
		System.out.println("ENTER NO. OF SUBJECTS: ");
		NumSub = sab.nextInt();
		   for(int i=1; i<=NumSub;i++) {
			   System.out.println("ENTER SCORE FOR SUBJECT "+i);
			   scores[i] = sab.nextInt();
			   sumsco += scores[i];
			  
			}
		   average = sumsco/NumSub;
		   System.out.println("THE AVERAGE OF THE SCORES IS: "+average);
		   
	
	}
}
