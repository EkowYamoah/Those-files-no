import java.util.Scanner;
import java.util.ArrayList;

public class NessaC {
		public static void main(String[] args) { 
			System.out.println("====================================================================================================================================");

			System.out.println("STUDENT ID\t"+"NAME\t\t\t"+"TOTAL FEES PAID\t\t\t"+"ARREARS\t\t\t"+"(X-x)^2");
			System.out.println("====================================================================================================================================");
			
			// declaring the required variables
			
					int IDs[]= {19100,19004,19010,19011,19103,19110,19123};
					double Totalfees=12500;
					String currency="GHC";
					String IDp="EX";
					double grandTotal=0;
					double arrears=0;
				double variance=0;
				double average=0;
				
						double standardDeviation=0;
				String names[]= {"VALERIA DICKSON","JONAS VIKES","NALLY DUKES","FRANCA KLINN","BUENOS VADAS","HELEN WANKI","REED ANDRES"};
				double TfeesPaid[]= {7500,10000,6700,8301,9700,6890,10000};
				
				double SODx=0;
				double x2=0;
				double arrearT=0;
				
				
				for(int i=0;i<IDs.length;i++) {
					grandTotal+=TfeesPaid[i];
					arrears=Totalfees-TfeesPaid[i];
					
					
					SODx+=x2*x2;
					arrearT+=arrears;
					
					average= 8441.57142857143;
					variance=(SODx)/TfeesPaid.length;
					standardDeviation=Math.sqrt(variance);
					x2=TfeesPaid[i]-average;
					System.out.println(IDp+IDs[i]+"\t\t"+names[i]+"\t"+"\t"+currency+" "+TfeesPaid[i]+"\t\t\t"+currency+" "+arrears+"\t\t"+x2*x2);
					
				
				}
				System.out.println("====================================================================================================================================");
				
				System.out.print("\n\t\t\t\t\t\t\t\t\t\t\t\tE(X-x)^2: "+SODx);
		
				
				System.out.println("\n\n");
				System.out.println("\t\t\t\t\t\t\t=================================================================================");
				System.out.println("\t\t\t\t\t\t\t| GRAND TOTAL: "+currency+" "+grandTotal+" \t\t\t\t\t\t\t|");
				System.out.println("\t\t\t\t\t\t\t| TOTAL ARREARS: "+currency+" "+arrearT+" \t\t\t\t\t\t\t|");
				System.out.println("\t\t\t\t\t\t\t| VARIANCE: "+variance+" \t\t\t\t\t\t\t|");
				System.out.println("\t\t\t\t\t\t\t| STANDARD DEVIATION: "+standardDeviation+" \t\t\t\t\t|");
				System.out.println("\t\t\t\t\t\t\t| AVERAGE: "+average+" \t\t\t\t\t\t\t|");
				System.out.println("\t\t\t\t\t\t\t=================================================================================");
		
		
		
	
	}
}
		