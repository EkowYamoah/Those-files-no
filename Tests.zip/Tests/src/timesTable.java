package tests;
import java.util.Scanner;


public class timesTable {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		int y;
		
		System.out.println("ENTER NUMBER HERE: ");
		x=sc.nextInt();
		
		for(int k =1;k<13;k++) {
			y=x*k;
			System.out.println(x+" "+"x"+" "+k+" "+"="+" "+y);
		}
		
	}
}
