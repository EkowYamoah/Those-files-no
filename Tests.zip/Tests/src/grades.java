import java.util.Scanner;


public class grades {

		public static void main(String args[]) {
			String Fname;
			String Lname;
			String Oname;
			int ID;
			int mark;
			String grade=null;
			
			Scanner input = new Scanner(System.in);
			
			System.out.println("GRADE CALCULATION SYSTEM");
			System.out.println("-------------------------");
			
			System.out.println("ENTER YOUR FIRST NAME: ");
			Fname = input.next();
			System.out.println("ENTER YOUR LAST NAME: ");
			Lname = input.next();
			System.out.println("ENTER YOUR ID HERE: ");
			ID	= input.nextInt();
			System.out.println("ENTER YOUR MARK HERE: ");
			mark = input.nextInt();
			System.out.println("-------------------------");
			System.out.println("-------------------------");
			System.out.println("-------------------------");
			if(mark>=80 && mark<=100) {
				grade = "A";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark>=75 && mark<80) {
				grade = "B+";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			
			}else if(mark>=70 && mark<75) {
				grade = "B";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark>=65 && mark<70) {
				grade = "C+";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}
			else if(mark>=60 && mark<65) {
				grade = "C";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark>=55 && mark<60) {
				grade = "D+";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark>=50 && mark<55) {
				grade = "D";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark>=40 && mark<50) {
				grade = "E";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}else if(mark<40) {
				grade = "F";
				System.out.println("NAME: "+Fname+" "+Lname);
				System.out.println("ID: "+ID);
				System.out.println("MARK: "+mark);
				System.out.println("GRADE: "+grade);
			}
		}
}
