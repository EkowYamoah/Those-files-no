
public class acessctrl {
	private int day = 2;
	private int month=12;
	private int year = 20;
	
	
	 public void setDate(int day, int month, int year) {
		 	this.day = 5;
		 	this.month= 10;
		 	this.year = 19;
		 	
	 }
			public String toMilitary(){
				return String.format("%02d:%02d:%02d", day,month,year);
			}
			public String toString() {
				return String.format("%02d:%02d:%02d %s", ((day==0||day==12)?12:day%12), month, year,(day<12?"AM":"PM"));
				
				//return String.format("%02d:%02d:02d %s", ((day==0 || day ==12)?:12:day%12), month, year, (day<12?"AM":"PM"));
			}
}
