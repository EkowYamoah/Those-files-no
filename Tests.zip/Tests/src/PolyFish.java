
public class PolyFish extends PolyAnimal {

}
