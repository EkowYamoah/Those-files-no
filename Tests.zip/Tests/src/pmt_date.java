import java.util.*;


public class pmt_date {
		public static void main(String args[]) {
	int original_date=0;
	int required = 2000;
	
	while(original_date<2000) {
		original_date+=182;
		System.out.println(original_date-182);
	}
}
}