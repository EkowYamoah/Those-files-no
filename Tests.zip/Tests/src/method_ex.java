import java.lang.Math;
import java.util.*;


public class method_ex {

public static String sayGreeting(String speaker, String listener) {
	
	String greet=null;
			
	System.out.println("Hello "+listener+",");
	
	System.out.println("My name is Professor "+speaker);
	
	greet=("Hello "+listener+"My name is Professor "+speaker);
	
	return greet;
}

public static double computeAreaCircle(double radius) {
	double pi;
	double area=0;
	pi=Math.PI;
	area=(Math.pow(radius,2))*pi;
	
	return area;
	
}




	public static void main(String[] args) {
		String sname,lname;
		int circNum=1;
		
		double [] counts = new double[3];
		Scanner kb = new Scanner(System.in);
		System.out.println("What is your name?: ");
		lname = kb.next();
		System.out.println("Who is speaking today? ");
		sname=kb.next();
		
		System.out.println("\t");
		
		sayGreeting(sname,lname);
		
		
		
		System.out.println("\t\t\t\t\t");
		
		
		for(int counter =0;counter<3;counter++) {
			
			while(counter<3) {
				System.out.println("Enter radius for circle "+counter+":");
				counts[counter]=kb.nextDouble();
				
				counter++;
				
			
		
		}
			
			System.out.println("\t\t");
			System.out.println("Area of circle "+circNum+ " is "+ computeAreaCircle(counts[0]));
			System.out.println("\t\t");
			circNum++;
			
			
			System.out.println("\t\t");
			System.out.println("Area of circle "+circNum+ " is "+ computeAreaCircle(counts[1]));
			System.out.println("\t\t");
			circNum++;
			
			System.out.println("\t\t");
			System.out.println("Area of circle "+circNum+ " is "+ computeAreaCircle(counts[2]));
			System.out.println("\t\t");
			circNum++;
			
	}
	}


}