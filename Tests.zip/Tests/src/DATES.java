
public class DATES{
	private int day;
	private int month;
	private int year;
	
	public DATES(int d, int m, int y) {
		month = m;
		day = d;
		year = y;
		
		System.out.printf("DOB: %s\n", this);
	}
	public String toString() {
		return String.format("%d/%d/%d", month, day, year);
			
	}
}