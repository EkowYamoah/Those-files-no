
public class static_main {

}
