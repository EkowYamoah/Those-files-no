
public class OclassMain {
	public static void main(String arg[]) {
		
	tuna tunaObject = new tuna(10);
	
	for(int i=0; i<5; i++) {
		tunaObject.add();
		System.out.printf("%s",tunaObject);
	}

	}
}
