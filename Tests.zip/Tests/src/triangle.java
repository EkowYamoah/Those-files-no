import java.util.Scanner;


public class triangle {
	public static void main(String[] args) {
	int a=0;
	int b=0;

	Scanner input = new Scanner(System.in);
	
		System.out.println("Enter first number: ");
		a=input.nextInt();
		System.out.println("Enter second number: ");
		b = input.nextInt();
		
		int c=a+b;
		System.out.println(a+" + "+b+" = "+c);
	

}
}