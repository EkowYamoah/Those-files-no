package tests;

public class Final {
	
	private String First;
	private String Last;
	private static  int number;
	
	
}
