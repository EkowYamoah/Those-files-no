import java.util.Scanner;
import java. util.ArrayList;


public class multiArray {
	
	public static void diplayString(String s[][]) {
		for(int r=0;r<s.length;r++) {
			for(int column=0;column<s[r].length;column++) {
				System.out.print(s[r][column]+"\t");
			}
			System.out.println();
		}
		
	}
	
	public static void display(int x[][]) {
		for(int row=0;row<x.length;row++) {
			for(int column=0;column<x[row].length;column++) {
				System.out.print(x[row][column]+"\t");
			}
			System.out.println();
		}
		
		
	}
	public static void main(String[] args) {
		String title[][]= new String[2][3];
		int cube[][] = new int[7][3];
		cube[0][0]=19100;
		cube[1][0]=19004;
		cube[2][0]=19010;
	    cube[3][0]=19011;
	    cube[4][0]=19103;
	    cube[5][0]=19110;
	    cube[6][0]=19123;
	    
	 
	    
	    title[0][0]="STUDENT ID";
	    title[0][1]="NAME";
	    title[0][2]="TOTAL FEES PAID";
				
	 
	    display(cube);
	    
	    
		
		
		
	}

}
