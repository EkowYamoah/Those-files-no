class PolyMain {
	public static void main(String[] args) {
		PolyDogList DLO = new PolyDogList();
		PolyDog d = new PolyDog();
		DLO.add(d);
	}

}
