package tests;

public class Linear {
	public static int linear(int arr[], int key) {
		int n = arr.length;
		
		for (int i =0;i < n;i++) {
			if(arr[i]==key) {
				return i;
			}
			
		}
		return -1;
	}
	
	public static void main(String [] args){try {
		int A [] = {10, 20, 30, 49, 50};
		int k =49;
		//int n = A.length;
		
		int result = linear(A,k);
		if(result == -1) {
			System.out.println("Element not found!!!");
		}else {
			System.out.println("Element found at index: "+ result);
		}
		
	}
catch(Exception e) {
	System.out.println("ERROR: "+e);
}
}
}