	import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
		 
		import java.io.FileReader; 

public class file_Demo {		  
		    public static void main(String args[]) throws FileNotFoundException  { 
		    	File file = new File("C:\\Users\\YME\\Desktop\\ML Notes.txt");
		    		Scanner fr = new Scanner(file);
		    		
		    		
		    		while(fr.hasNextLine()) {
		    			String text = fr.nextLine();
		    			System.out.println(text);
		    	}
}
}