
public class PolyAnimal {
	
}
