package tests;
import java.util.Scanner;

public class whitespace {
	public static void main(String[] args){try {
	 //Scanner sc = new Scanner(System.in); // to take input from user
	char sp = ' ';
	int whitespace=0;
		String sentence="Latifah is bad stubbornpainintheassinChina";
		
		//System.out.println("ENTER STRING HERE: ");
		//sentence=sc.next();
		
		 
		
		for(int i = 0; i <sentence.length();i++) {
			if(sentence.charAt(i)==sp) {
				whitespace+=1;
				
			}
			
			continue;
			}
		System.out.println("TOTAL WHITESPACES: "+whitespace);
		
	}catch(Exception e) {
		System.out.println("ERROR: "+e);
		
		}
	}
		
}


