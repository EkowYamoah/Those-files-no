
public class static_ex {

}
