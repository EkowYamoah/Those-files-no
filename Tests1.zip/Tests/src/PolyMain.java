class PolyMain {
	public static void main(String[] args) { try {
		
		PolyAnimalList ALO = new PolyAnimalList();
		PolyDog dog = new PolyDog();
		PolyFish fish = new PolyFish();
		ALO.add(dog);
		ALO.add(fish);
	
		for(int i=0;i<=8;i++) {
//			System.out.println(ALO[i]);
		}
	}
	catch(Exception e) {
		System.out.println("ERROR: "+e);
		}
	}
}
