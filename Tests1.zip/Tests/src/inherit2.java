
public class inherit2 extends inherit3{
	
	void third() {
		System.out.println("this inherit2 is awesome");
	}

}
