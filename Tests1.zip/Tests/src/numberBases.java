//package tests;

public class numberBases {
	public static void main(String args[]) {
		String s ="the lazy cat";
		
	
		System.out.println(s.toUpperCase());
		
		
	}

}
