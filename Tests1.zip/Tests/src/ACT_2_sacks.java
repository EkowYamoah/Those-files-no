import java.util.*;

public class ACT_2_sacks {
	public static void main(String args[]) {
		int donationType;
		String volunteer;
		
		Scanner in = new Scanner(System.in);
		System.out.println("SACKS FIFTH AVENUE ");
		System.out.println("DONATIONS POINT");
	System.out.println("ENTER DONATIONS TYPE: ");
	System.out.println("1. CLOTHING ");
	System.out.println("2. OTHER DONATIONS ");
	 
		donationType = in.nextInt();
		
	if(donationType == 1) {
		volunteer = "REGINA";
		System.out.println("PLEASE GIVE YOUR DONATIONS TO "+ volunteer);
		System.out.println("THANK YOU VERY MUCH FOR YOUR DONATIONS!!!");
	}
	else if(donationType == 2) {
		volunteer = "MARCO";
		System.out.println("PLEASE GIVE YOUR DONATIONS TO "+ volunteer);
		System.out.println("THANK YOU VERY MUCH FOR YOUR DONATIONS!!!");
	}else {
		System.out.println("PLEASE SELECT A VALID OPTION");
		
		main(args);
	}
	
		
		
	}
}
