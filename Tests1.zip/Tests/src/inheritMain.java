// THIS PROGRSAM HAS TWO PARTS 
// 1. INHERITANCE
// 2. POLYMORPHISM
// JUST COMMENT OUT THE UNLUCKY ONE TO KNOW HOW THE LUCKY ONE WORKS :)


public class inheritMain {
	// ****INHERITANCE ONLY	STARTS HERE***
	public static void  main(String [] args) {
//	
//	
//		inherit1 inherit1Object = new inherit1();
//		inherit2 inherit2Object = new inherit2();
//		
//		inherit1Object.third();
//		inherit2Object.third();
//		
//		 ***INHERITANCE ENDS HERE***
//	}
	
	// ****POLYMORPHISM ONLY	STARTS HERE(demonstrating with polymorphic arrays)***
//			with arrays
		//		inherit3 polyArr[]= new inherit3[2];
//		polyArr[0]= new inherit2();
//		polyArr[1]=new inherit1();
//	
//		for(int p =0; p<2;++p) {
//			polyArr[p].third();
//		}
		
//		WITH ARGUMENTS
		inherit4 fork = new inherit4();
		inherit3 ba = new inherit3();
		inherit3 po = new inherit2();
		
		fork.baby(ba);
		fork.baby(po);
	
	// ****POLYMORPHISM ENDS HERE***
	}
}
