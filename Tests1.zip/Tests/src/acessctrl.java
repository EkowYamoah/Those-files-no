
public class acessctrl {
	private int hour = 2;
	private int minute=12;
	private int second = 20;
	
	
	 public void setDate(int hour, int minute, int second) {
		 	this.hour = 5;
		 	this.minute= 10;
		 	this.second = 19;
		 	
	 }
			public String toMilitary(){
				return String.format("%02d:%02d:%02d", hour,minute,second);
			}
			public String toString() {
				return String.format("%02d:%02d:%02d %s", ((hour==0||hour==12)?12:hour%12), minute, second,(hour<12?"AM":"PM"));
				
//				return String.format("%02d:%02d:02d %s", ((day==0 || day ==12)?:12:day%12), month, year, (day<12?"AM":"PM"));
			}
}
