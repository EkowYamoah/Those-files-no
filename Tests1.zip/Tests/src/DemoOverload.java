import java.util.*;
import java.text.SimpleDateFormat;

public class DemoOverload {
	
	public static void displayDate(String Month) {
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("MMMMMMMM");
		
		System.out.println(df.format(date));
	}
	
	public static void displayDate(String Month, int day) {
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd MMMMMMMMMMM");
		
		System.out.println(df.format(date));
		
		
	}
	public static void displayDate(String Month, int day, int year) {
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd MMMMMMMMMM yyyy hh:mm:ss a z");
		
		System.out.println(df.format(date));
	}	
	
	
	
	public static void main(String args[]) {
		
		displayDate("a");
		displayDate("a",1);
		displayDate("a",1,1);
		
		
	}

}
