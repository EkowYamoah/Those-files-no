//package tests;

import java.util.Scanner;

public class MultipleOperands {
	
	public static int Add(int a,int b) {
		int c=a+b;
		
		
		return c;
		
	}
	public static int Subtract(int a,int b) {
		int c=a-b;
		
		
		return c;
		
	}
	public static int product(int a,int b) {
		int c=a*b;
		
		
		return c;
		
	}
	public static int quotient(int a,int b) {
		int c=a+b;
		
		
		return c;
		
	}
	public static int mod(int a,int b) {
		int c=a%b;
		
	
		return c;
		
	}
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int x,y;
		
		System.out.println("INPUT FIRST NBUMBER: ");
		x = in.nextInt();
		System.out.println("INPUT SECOND NBUMBER: ");
		y = in.nextInt();
		
		
		System.out.println(x+" "+"+"+" "+y+" "+"="+" "+Add(x,y));
		System.out.println(x+" "+"-"+" "+y+" "+"="+" "+Subtract(x,y));
		System.out.println(x+" "+"x"+" "+y+" "+"="+" "+product(x,y));
		System.out.println(x+" "+"/"+" "+y+" "+"="+" "+quotient(x,y));
		System.out.println(x+" "+"mod"+" "+y+" "+"="+" "+mod(x,y));
	}

}
