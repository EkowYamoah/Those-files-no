
public class mainObject {
	public static void main(String[] args) {
	objects object=new objects();
	System.out.println(object.toMilitary());
	System.out.println(object.toString());

	object.setTime(14, 34, 3);
	System.out.println(object.toMilitary());
	System.out.println(object.toString());
	
	
  }
}