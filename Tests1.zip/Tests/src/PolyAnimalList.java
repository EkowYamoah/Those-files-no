
public class PolyAnimalList {
	PolyFish PFO = new PolyFish();
	PolyDog PDO = new PolyDog();
	
	
	private PolyAnimal[] thelist = new PolyAnimal[5];
	private int i = 0;
	
	public void add(PolyAnimal a) {
		
		if(i<thelist.length) {
			thelist[i]=a;

			System.out.println("Animal added at index "+i);
			i++;
			}
	}
}
