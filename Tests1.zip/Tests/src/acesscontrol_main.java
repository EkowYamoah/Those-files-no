
public class acesscontrol_main {
	public static void main(String[] args) {
		 
		acessctrl accessctrlobj = new acessctrl();
		
		System.out.println(accessctrlobj.toMilitary());
		System.out.println(accessctrlobj.toString());
		
		
		accessctrlobj.setDate(15,30,6);
		System.out.println(accessctrlobj.toMilitary());
		System.out.println(accessctrlobj.toString());
		
		
	}
}
