//package tests;
import java.util.ArrayList;
import java.util.Scanner;


public class array {
	public static void Aint(int x[]) {
		
		for(int k=0;k<x.length;k++) {
			System.out.print(k+" ");
			
		
		}
		
		
	}
	
	
	public static void main(String [] args) {
		Scanner InA = new Scanner(System.in);
		int [] A = new int [5];
		
		for(int i=0;i<A.length;i++) {
			System.out.println("ENTER FIGURE FOR INDEX: "+i);
			A[i]=InA.nextInt();
			
			
			}
		System.out.println("\n\n");
		for(int k =0;k<A.length;k++) {
			
			System.out.print(A[k]+"\t");
		}
	}

}
