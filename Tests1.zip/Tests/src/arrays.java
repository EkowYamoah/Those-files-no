import java.util.Scanner;
import java.util.ArrayList;

class arrays{
	public static void main(String arg[]) {
		double [] array = new double[10];
		Scanner input = new Scanner(System.in);
		
		int ps=0;
		System.out.println("Enter No. of Quizzes Taken: ");
		ps=input.nextInt();
		System.out.println(" ");
		System.out.println(" ");
		
		
		int counter=0;
		int TNo=1;
		double sum=0, average=0;
		
			while(counter<ps) {
				for(int i=0;i<ps;i++) {
					System.out.println("Enter score for quiz "+TNo);
					array[i]=input.nextInt();
					sum=array[i]+sum;
					average=sum/ps;
					counter++;
					TNo++;
						
						
				}
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(" ");
				System.out.println("SUM: "+sum);
				System.out.println("AVERAGE: "+average);
			}
		
		
	}
}