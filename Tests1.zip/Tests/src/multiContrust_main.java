
	public class multiContrust_main {
			public static void main(String[] args) {
				multipleConstructors multconstobj = new multipleConstructors();
				
				multipleConstructors multconstobj2 = new multipleConstructors(13);
				multipleConstructors multconstobj3= new multipleConstructors(13,23);
				multipleConstructors multconstobj4 = new multipleConstructors(13,23,59);
				
				
				System.out.printf("%s\n", multconstobj.toMilitary());
				System.out.printf("%s\n", multconstobj2.toMilitary());
				System.out.printf("%s\n", multconstobj3.toMilitary());
				System.out.printf("%s\n", multconstobj4.toMilitary());
			}
}
