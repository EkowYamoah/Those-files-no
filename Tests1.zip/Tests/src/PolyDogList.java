public class PolyDogList {
	private PolyDog[] thelist = new PolyDog[5];
	private int counter=0;
	
	public void add(PolyDog d) {
		if(counter<thelist.length) {
			thelist[counter]=d;
			System.out.println("Dog added at index "+ counter);
			counter++;
		}
	}
	
}

