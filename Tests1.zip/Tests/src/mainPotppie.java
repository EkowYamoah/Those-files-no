
public class mainPotppie {
	public static void main(String[] args) {
		potpie potObject = new potpie(4,5,2006);
		
		foodie foodObject = new foodie("Ekow", potObject);
			
		
		
		System.out.println(foodObject);
	}
}
