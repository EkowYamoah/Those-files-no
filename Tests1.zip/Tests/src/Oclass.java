import java.util.Scanner;

public class Oclass {
	public static void main(String[] args) {
		
	}

}
