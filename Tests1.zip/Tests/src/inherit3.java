//This is the super class
public class inherit3 {
	//**INHERITANCE**
//	public void third() {
//	System.out.println("This is the 3rd's method");
//	}
	
	//** POLYMORPHISM***
	void third() {
		System.out.println("this inherit3 is awesome");
	}
}
