
public enum Enum_example {
	Ekow("nice", "23"),
	Seth("hot","8"),
	Yvette("cool", "11");
	
	
	private final String desc;
	private final String year;
	
	
	Enum_example(String description, String birthday){
		desc = description;
		year = birthday;
	}
	

	public String getDesc() {
		return desc;
	}
	
	public String getYear() {
		return year;
	}
	
}
