
public class inherit1 extends inherit2 {
//	*** INHERITANCE***
//	public void third() {
//		System.out.println("This is the 3rd method altered in sub class 1");
//		}

//	***POLYMORPHISM**
	void third() {
		System.out.println("this inerit1 is awesome");
	}
}
