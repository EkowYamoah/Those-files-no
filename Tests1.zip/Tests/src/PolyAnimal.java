
public class PolyAnimal {
	
	
	public void noice() {
		System.out.println("Animals don't make noise");
	}
}
