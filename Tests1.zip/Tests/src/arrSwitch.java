import java.util.Scanner;

public class arrSwitch {
	public static void main(String args[]) {try {
	int Arr [] = {1,2,3,4,5,6};
	int Sarr[] = {16,18,20,22,24};
	
//	int ages = Arr
	
}catch(Exception e) {
	System.out.println("ERROR: "+e);
	}
}
}