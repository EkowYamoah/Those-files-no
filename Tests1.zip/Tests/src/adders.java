//package tests;

import java.util.Scanner;
import java.lang.Double;

public class adders {
	
	public static void main(String [] args) {
	Scanner in = new Scanner(System.in);
		
	double a;
	double b;
	
		System.out.println("First Number: ");
		a=in.nextDouble();
		System.out.println("second Number: ");
		b=in.nextDouble();
		
		double c = a+b;
		
		int value = (int)c;
		System.out.println(value);
		
	}
	


}
