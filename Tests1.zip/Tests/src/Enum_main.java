
public class Enum_main {
	public static void main(String[] args) {
		for(Enum_example people: Enum_example.values() )
			System.out.printf("%s\t%s\t%s\n",people, people.getDesc(),people.getYear());
	}

}