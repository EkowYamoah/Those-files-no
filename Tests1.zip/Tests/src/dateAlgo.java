import java.util.*;
import java.text.*;





	public class dateAlgo {
		  public static boolean OnlyAlpha(String FSSNIT) 
		    { 
		        return ((FSSNIT != null) 
		                && (!FSSNIT.equals("")) 
		                && (FSSNIT.matches("^[a-zA-Z]*$"))); 
		    } 	
		
		public static void main(String[] args) throws Exception{
				try {
				Scanner sc = new Scanner(System.in);
				char ISSNIT;
				String SSNIT;
				String SSNIT_NO;
				System.out.println("SSNIT NO.: ");
				
				SSNIT=sc.nextLine();
				
					
			
				char d1=SSNIT.charAt(7);
				char d2=SSNIT.charAt(8);
				char m1=SSNIT.charAt(5);
				char m2=SSNIT.charAt(6);
				char y1=SSNIT.charAt(3);
				char y2=SSNIT.charAt(4);
		System.out.print("DATE OF BIRTH: ");
				
				
				StringBuilder sb = new StringBuilder();
				sb.append(d1);
				sb.append(d2);
				sb.append("/");
				sb.append(m1);
				sb.append(m2);
				sb.append("/");
				sb.append(y1);
				sb.append(y2);
				
				SSNIT_NO = sb.toString();
				ISSNIT=d1; 
				
			
				if(SSNIT_NO.length()==13) {
			
					System.out.println(SSNIT_NO);
				
				
				Date date1=new SimpleDateFormat("dd/MMMM /yyyy").parse(SSNIT_NO);  
				System.out.println(SSNIT_NO+"\t \t"+date1);
			}
				else {
					System.out.println(SSNIT_NO);
				}
				}catch(StringIndexOutOfBoundsException e){
				
					System.out.println("Invalid SSNIT ID");	
										
				}
	}
}