//package tests;
import java.util.Scanner;
import java.text.*;

public class finalMain {
	public static void  main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
	}

}
