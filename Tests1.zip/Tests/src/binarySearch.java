

public class binarySearch {
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		int mabelclits[]= {20,30,35,40,45,50,62};
			Binary_Search(mabelclits, 35);
			
			
			
	}
	
	
	public static int Binary_Search(int A [], int N) {
		int lowestLoc = 0;
		int highestLoc = A.length-1;
		
		while(highestLoc>=lowestLoc) {
			int middle=(lowestLoc+highestLoc)/2;
			
			if(A[middle]==N) {
				System.out.print("Number found at: ");
				return middle;
				
			}
			else if(A[middle]>N) {
				
				highestLoc=middle-1;
				
			}
			else {
				lowestLoc=middle+1;
			}
			// if program makes it to this point then N is not in Array
	
		}
		
		System.out.print("Number not found!!! ");
		
		
	



return -1;
   }	
}
