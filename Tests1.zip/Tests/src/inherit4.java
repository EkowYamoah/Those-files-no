
public class inherit4 {

	public void baby(inherit3 x){
		x.third();
	}
}
